# online-movie-ticket-booking-system
This is an online movie ticket booking website  made using following technologies:-
  1. Python-3.6
  2. Django-2.0.3
  3. JavaScript
  4. JQuery-3.3.1
  5. Bootstrap3

This project contains following apps:-
  1. theatre app
  2. movie app
  3. booking app
  4. home app
 
 In this project custom user model has been used rather than default user model.

 There are list and detail views of theatre, movie etc. 
 Movie list view displays the movie.
 Theatre list view displays all the theatres in a city.
 Booking list view displays our booking.
 
